-- MySQL dump 10.16  Distrib 10.1.22-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u495083010_web
-- ------------------------------------------------------
-- Server version	10.1.22-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activite`
--

DROP TABLE IF EXISTS `activite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activite` (
  `N°` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) DEFAULT NULL,
  `nomAct` varchar(255) DEFAULT NULL,
  `description` mediumtext,
  `dateAct` date NOT NULL,
  PRIMARY KEY (`N°`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activite`
--

/*!40000 ALTER TABLE `activite` DISABLE KEYS */;
INSERT INTO `activite` VALUES (10,4,'test2','test2','0000-00-00'),(11,2,'Saut Parachute','On va voler omg','2017-04-19');
/*!40000 ALTER TABLE `activite` ENABLE KEYS */;

--
-- Table structure for table `activiteterminee`
--

DROP TABLE IF EXISTS `activiteterminee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activiteterminee` (
  `N°` int(11) NOT NULL,
  `idUser` int(11) DEFAULT NULL,
  `nomAct` varchar(255) DEFAULT NULL,
  `description` mediumtext,
  `dateAct` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activiteterminee`
--

/*!40000 ALTER TABLE `activiteterminee` DISABLE KEYS */;
/*!40000 ALTER TABLE `activiteterminee` ENABLE KEYS */;

--
-- Table structure for table `activitevotee`
--

DROP TABLE IF EXISTS `activitevotee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activitevotee` (
  `N°` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) DEFAULT NULL,
  `nomAct` varchar(255) DEFAULT NULL,
  `description` mediumtext,
  `dateAct` date DEFAULT NULL,
  `votes` int(11) DEFAULT NULL,
  PRIMARY KEY (`N°`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activitevotee`
--

/*!40000 ALTER TABLE `activitevotee` DISABLE KEYS */;
INSERT INTO `activitevotee` VALUES (14,2,'tets','test','2017-04-19',8),(15,4,'test','test',NULL,6),(16,4,'testact','un joli test','2017-05-20',NULL),(17,4,'PL Guy','PL Guy','0000-00-00',NULL),(18,8,'Réseau !','Serveurs !','2017-05-21',NULL),(19,8,'Réseau !','Serveurs !','2017-05-21',NULL);
/*!40000 ALTER TABLE `activitevotee` ENABLE KEYS */;

--
-- Table structure for table `commentaire`
--

DROP TABLE IF EXISTS `commentaire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commentaire` (
  `N°` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) DEFAULT NULL,
  `dateHeure` datetime DEFAULT NULL,
  `texte` mediumtext,
  `idPhoto` int(11) DEFAULT NULL,
  PRIMARY KEY (`N°`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commentaire`
--

/*!40000 ALTER TABLE `commentaire` DISABLE KEYS */;
INSERT INTO `commentaire` VALUES (20,3,'2017-04-15 16:30:34','omg omg du quidditch!!',2),(21,3,'2017-04-15 17:32:31','Ouai! trop bien!',2),(22,2,'2017-04-15 17:32:47','Arrete de parler tout seul Guy',2),(23,2,'2017-04-15 17:33:37','j\'aime le parachute',1),(29,3,'2017-04-15 21:02:55','il est beau Harry...',2),(30,3,'2017-04-15 21:55:32','ah ouais??',1),(31,2,'2017-04-15 22:13:40','wouhaa!',1),(32,6,'2017-04-16 13:05:21','C\'est moi!! omg omg!',2),(33,3,'2017-04-18 09:07:56','j\'aime les penis',2),(34,3,'2017-04-18 09:10:16','hooooooo harry avec son gros balais',2),(35,8,'2017-04-20 16:41:21','Bonjour ! Beau parachute !',1),(36,8,'2017-04-20 16:43:12','Bonjour ! Beau parachute !',1),(37,8,'2017-04-20 16:48:13','Bonjour ! Beau parachute !',1);
/*!40000 ALTER TABLE `commentaire` ENABLE KEYS */;

--
-- Table structure for table `photo`
--

DROP TABLE IF EXISTS `photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photo` (
  `N°` int(11) NOT NULL AUTO_INCREMENT,
  `image` mediumtext,
  `idActivite` int(11) DEFAULT NULL,
  PRIMARY KEY (`N°`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photo`
--

/*!40000 ALTER TABLE `photo` DISABLE KEYS */;
INSERT INTO `photo` VALUES (1,'Pictures/parachute.jpg\r\n',11),(2,'Pictures/quidditch.jpg',11);
/*!40000 ALTER TABLE `photo` ENABLE KEYS */;

--
-- Table structure for table `produit_vente`
--

DROP TABLE IF EXISTS `produit_vente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produit_vente` (
  `N°` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `prix` int(11) DEFAULT NULL,
  `photo` mediumtext,
  PRIMARY KEY (`N°`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produit_vente`
--

/*!40000 ALTER TABLE `produit_vente` DISABLE KEYS */;
INSERT INTO `produit_vente` VALUES (1,'Stylo',5,'/Projet2/Pictures/Boutique/stylo.jpg'),(2,'Mug',8,'/Projet2/Pictures/Boutique/mug.jpg'),(3,'Sweat',35,'/Projet2/Pictures/Boutique/sweat.jpg');
/*!40000 ALTER TABLE `produit_vente` ENABLE KEYS */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `N°` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `avatar` mediumtext,
  `email` mediumtext,
  `motDePasse` varchar(255) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL,
  `IDuserActiviteVote` int(11) NOT NULL,
  PRIMARY KEY (`N°`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2,'Cristille','Pierre-Laurent','Pictures/Avatars/pl.png','mail@mail.fr','c184301c5718c75abd6f97cadf4f51ef49c0ef90',0,0),(3,'Cuguen','Guy','Pictures/Avatars/avata012r.png','mail2@mail.fr','8913dbc65c2fd0c0798c7a94dc0faa94e1955ed7',0,0),(4,'Brousset','Remy',NULL,'rbrousset@cesi.fr','6934105ad50010b814c933314b1da6841431bc8b',1,0),(9,'Le Lay','Dylan',NULL,'lelay.dylan@gmail.com','7110eda4d09e062aa5e4a390b0a572ac0d2c0220',0,0),(8,'Le Lay','Dylan',NULL,'lelay.dylan@gmail.com','7110eda4d09e062aa5e4a390b0a572ac0d2c0220',0,0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

--
-- Table structure for table `useractivitevote`
--

DROP TABLE IF EXISTS `useractivitevote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `useractivitevote` (
  `N°` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) NOT NULL,
  `idActiviteVotee` int(11) NOT NULL,
  PRIMARY KEY (`N°`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useractivitevote`
--

/*!40000 ALTER TABLE `useractivitevote` DISABLE KEYS */;
INSERT INTO `useractivitevote` VALUES (73,4,14),(74,4,15),(75,3,14),(76,3,15),(77,3,17),(78,3,16),(79,8,14),(80,9,14),(81,4,20),(82,4,21);
/*!40000 ALTER TABLE `useractivitevote` ENABLE KEYS */;

--
-- Dumping events for database 'u495083010_web'
--

--
-- Dumping routines for database 'u495083010_web'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-20 20:03:42
